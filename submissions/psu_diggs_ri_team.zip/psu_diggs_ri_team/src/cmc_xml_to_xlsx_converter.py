# Install the required library for Excel image integration
!pip install xlsxwriter

import pandas as pd
import numpy as np
import re
import matplotlib.pyplot as plt
import os
import xml.etree.ElementTree as ET
import string

print("🚀 Starting Super DIGGS Converter - Dynamic XML Parsing Edition...")

# =====================================================================
# 1. LOAD DIGGS XML FILE FROM DISK
# =====================================================================
xml_file = 'RI_Project.xml'
print(f"📂 Loading XML file: {xml_file}...")

if not os.path.exists(xml_file):
    raise FileNotFoundError(f"Cannot find {xml_file}. Please ensure the file is uploaded to your environment.")

# Parse the XML tree
tree = ET.parse(xml_file)
root = tree.getroot()

# Define namespaces
ns = {
    'diggs': 'http://diggsml.org/schemas/3',
    'gml': 'http://www.opengis.net/gml/3.2'
}

# =====================================================================
# 2. EXTRACT PROJECT SUMMARY & TOTAL CMC COLUMNS (NO HARDCODING)
# =====================================================================
print("📥 Extracting Project Summary and Details...")

project_elem = root.find('.//diggs:Project', ns)
project_name = project_elem.find('gml:name', ns).text.strip() if project_elem is not None else "Unknown Project"

# Extract remarks content
proj_content_elem = root.find('.//diggs:Project//diggs:Remark/diggs:content', ns)
proj_content = proj_content_elem.text.strip() if proj_content_elem is not None else ""

act_content_elem = root.find('.//diggs:LinearGroutingActivity//diggs:Remark/diggs:content', ns)
act_content = act_content_elem.text.strip() if act_content_elem is not None else ""

full_remarks = proj_content + " | " + act_content

# Parse the Total Installed CMCs dynamically from the remark string
num_match = re.search(r'Total Installed CMCs:\s*(\d+)', full_remarks, re.IGNORECASE)
if num_match:
    num_piles = int(num_match.group(1))
    print(f"📊 Found Total Installed CMCs: {num_piles}")
else:
    raise ValueError("Could not find 'Total Installed CMCs' in the XML remarks.")

# Build Summary Dataframe
summary_list =[{"Property": "Project Name", "Value": project_name}]
for item in full_remarks.split('|'):
    if ':' in item:
        key, val = item.split(':', 1)
        summary_list.append({"Property": key.strip(), "Value": val.strip()})

df_summary = pd.DataFrame(summary_list)

# =====================================================================
# 3. EXTRACT GRID GEOMETRY & MAP DATA (ROBUST NAMESPACE HANDLING)
# =====================================================================
print("📥 Extracting Grid Geometry and CMC data...")

# Helper function to find elements safely ignoring prefixes
def get_elements_by_tag(root_element, tag_name):
    return [e for e in root_element.iter() if e.tag.split('}')[-1] == tag_name]

low_elems = get_elements_by_tag(root, 'low')
high_elems = get_elements_by_tag(root, 'high')
pos_elems = get_elements_by_tag(root, 'pos')
offset_elems = get_elements_by_tag(root, 'offsetVector')

# Safety checks
if not low_elems or not high_elems or not pos_elems:
    raise ValueError("Could not find grid bounding elements (<low>, <high>, or <pos>) in the XML.")
if not offset_elems:
    raise ValueError("Could not find <offsetVector> elements in the XML.")

# Grid bounds
low_vals =[int(x) for x in low_elems[0].text.split()]
high_vals =[int(x) for x in high_elems[0].text.split()]
low_col, low_row = low_vals[0], low_vals[1]
high_col, high_row = high_vals[0], high_vals[1]

# Compute dimensions dynamically
cols = high_col - low_col + 1
rows = high_row - low_row + 1

# Origin position
pos_vals =[float(x) for x in pos_elems[0].text.split()]
origin_x, origin_y = pos_vals[0], pos_vals[1]

# Offset vectors (Step sizes for columns and rows)
if len(offset_elems) >= 2:
    offset_1 =[float(x) for x in offset_elems[0].text.split()]
    offset_2 =[float(x) for x in offset_elems[1].text.split()]
    offset_x = offset_1[0]
    # Handle single digit vs coordinate pairs in offsetVector
    offset_y = offset_2[1] if len(offset_2) > 1 else offset_2[0]
else:
    # If there's only 1 offsetVector containing both X and Y spacing
    offset_vals =[float(x) for x in offset_elems[0].text.split()]
    offset_x = offset_vals[0]
    offset_y = offset_vals[1] if len(offset_vals) > 1 else offset_vals[0]

# Parse Execution Data (Depth and Volume)
grid_path = './/diggs:measurement/diggs:Test/diggs:outcome/diggs:TestResult/diggs:results/diggs:ResultSet/diggs:dataValues'
grid_data_elem = root.find(grid_path, ns)

if grid_data_elem is None:
    raise ValueError("Could not locate Grid Map dataValues in the XML hierarchy.")

grid_vals =[float(x.strip()) for x in grid_data_elem.text.replace('\n', ',').split(',') if x.strip()]

# Split flat list into depths and volumes
depth_list = grid_vals[0::2]
volume_list = grid_vals[1::2]

# Compute true geometry based on the GML configuration
grid_rows =[]
for i in range(num_piles):
    row_idx = i // cols
    col_idx = i % cols
    
    easting = origin_x + (col_idx * offset_x)
    northing = origin_y + (row_idx * offset_y)
    
    grid_rows.append({
        "CMC_ID": f"CMC-{i+1}",
        "Easting (X)": easting,
        "Northing (Y)": northing,
        "Achieved Depth (m)": depth_list[i] if i < len(depth_list) else None,
        "Grout Volume (m3)": volume_list[i] if i < len(volume_list) else None
    })

df_grid = pd.DataFrame(grid_rows)

# =====================================================================
# 4. EXTRACT SENSOR DATA (TIME SERIES)
# =====================================================================
print("📥 Extracting real-time rig sensor data...")

ts_path = './/diggs:constructionActivity//diggs:ContinuousGrouting//diggs:GroutingTimeSeries//diggs:dataValues'
ts_data_elem = root.find(ts_path, ns)

ts_rows =[]
if ts_data_elem is not None:
    ts_vals =[float(x.strip()) for x in ts_data_elem.text.replace('\n', ',').split(',') if x.strip()]
    
    for i in range(0, len(ts_vals), 6):
        if i+5 < len(ts_vals):
            ts_rows.append({
                "Depth (m)": ts_vals[i], 
                "Rotation (rpm)": ts_vals[i+1],
                "Torque (kN.m)": ts_vals[i+2], 
                "Thrust (kN)": ts_vals[i+3],
                "Grout Pressure (bar)": ts_vals[i+4], 
                "Grout Flow (L/min)": ts_vals[i+5]
            })
df_ts = pd.DataFrame(ts_rows)

# =====================================================================
# 5. GENERATE CMC COLUMN VISUALIZATION (WITH ENGINEERING GRID)
# =====================================================================
print("🎨 Generating CMC Construction Layout Drawing...")

plt.figure(figsize=(14, 10), dpi=300)
ax = plt.gca()

# 1. Calculate project boundary
min_x = df_grid['Easting (X)'].min()
max_x = df_grid['Easting (X)'].max()
min_y = df_grid['Northing (Y)'].min()
max_y = df_grid['Northing (Y)'].max()

project_length = max_x - min_x
project_width = max_y - min_y

# 2. Calculate CMC spacing (drop_duplicates avoids spacing of 0.0 in grids)
dx_series = df_grid['Easting (X)'].drop_duplicates().sort_values().diff().dropna()
dy_series = df_grid['Northing (Y)'].drop_duplicates().sort_values().diff().dropna()

dx = dx_series.min() if not dx_series.empty else offset_x
dy = dy_series.min() if not dy_series.empty else offset_y

# Ensure no division by zero in case of identical coordinates 
if dx == 0: dx = 1
if dy == 0: dy = 1

# 3. Draw project boundary rectangle
plt.plot([min_x, max_x, max_x, min_x, min_x],[min_y, min_y, max_y, max_y, min_y],
    linewidth=2,
    color='black',
    zorder=2
)

# 4. Add engineering dimension annotations
plt.text(
    (min_x + max_x) / 2,
    min_y - dy * 1.5,
    f"Length = {project_length:.2f} m",
    ha='center',
    fontsize=11
)

plt.text(
    min_x - dx * 1.8,
    (min_y + max_y) / 2,
    f"Width = {project_width:.2f} m",
    rotation=90,
    va='center',
    ha='center',
    fontsize=11
)

# 5. Create grid labeling system
cols_count = int(round(project_length / dx)) + 1
rows_count = int(round(project_width / dy)) + 1

# Generate enough alphabetical labels even if cols > 26 (A-Z, A-Z)
extended_uppercase = string.ascii_uppercase * (cols_count // 26 + 1)
col_labels = list(extended_uppercase)[:cols_count]
row_labels = list(range(1, rows_count + 1))

# 6. Draw grid lines
for i in range(cols_count):
    x = min_x + i * dx
    plt.axvline(x, linewidth=0.3, alpha=0.5, color='gray', zorder=1)

for j in range(rows_count):
    y = min_y + j * dy
    plt.axhline(y, linewidth=0.3, alpha=0.5, color='gray', zorder=1)

# 7. Display grid labels
for i, label in enumerate(col_labels):
    x = min_x + i * dx
    plt.text(x, max_y + dy * 0.4, label, ha='center', fontsize=10, fontweight='bold')

for j, label in enumerate(row_labels):
    y = min_y + j * dy
    plt.text(min_x - dx * 0.6, y, str(label), va='center', ha='right', fontsize=10, fontweight='bold')

# 8. Keep CMC columns drawn as circular markers
plt.scatter(
    df_grid['Easting (X)'],
    df_grid['Northing (Y)'],
    s=80,
    facecolors='white',
    edgecolors='black',
    zorder=3
)

# Hide native plot spines to keep it completely clean (we drew the boundary)
ax.spines['top'].set_visible(False)
ax.spines['right'].set_visible(False)
ax.spines['bottom'].set_visible(False)
ax.spines['left'].set_visible(False)

# 9. Maintain engineering drawing style
plt.axis('equal')
plt.xlabel('Easting (m)')
plt.ylabel('Northing (m)')
plt.title(f'CMC Column Layout Plan ({num_piles} Columns)', fontsize=16, fontweight='bold', pad=30)

# 10. Export high resolution drawing
plot_file = 'cmc_layout_with_grid.png'
plt.savefig(plot_file, dpi=300, bbox_inches='tight')
plt.close()

# =====================================================================
# 6. SAVE TO COMPREHENSIVE EXCEL FILE
# =====================================================================
excel_output = 'Project_Comprehensive_Data.xlsx'
print(f"💾 Saving data to {excel_output}...")

with pd.ExcelWriter(excel_output, engine='xlsxwriter') as writer:
    df_summary.to_excel(writer, sheet_name='1_Project_Summary', index=False)
    df_grid.to_excel(writer, sheet_name='2_Grid_Map_Data', index=False)
    
    if not df_ts.empty:
        df_ts.to_excel(writer, sheet_name='3_Rig_Sensor_Data', index=False)
    
    # Adjust column widths
    sheets_to_format =['1_Project_Summary', '2_Grid_Map_Data']
    if not df_ts.empty:
        sheets_to_format.append('3_Rig_Sensor_Data')
        
    for sheet in sheets_to_format:
        writer.sheets[sheet].set_column('A:F', 20)
    
    # Insert Visualization Sheet
    ws_plot = writer.book.add_worksheet('4_CMC_Layout_Visualization')
    ws_plot.write('A1', 'CMC Construction Layout Plan (Extracted dynamically from DIGGS)')
    ws_plot.insert_image('A3', plot_file)

print(f"✅ Success! File ready for download: {excel_output}")

from google.colab import files
files.download(excel_output)