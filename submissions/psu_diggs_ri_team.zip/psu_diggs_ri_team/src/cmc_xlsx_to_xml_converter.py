import pandas as pd
from lxml import etree
import os

print("🚀 Updating DIGGS XML from Excel (All Sheets)")

xml_file = "RI_Project.xml"
excel_file = "Project_Comprehensive_Data.xlsx"
output_xml = "RI_Project_UPDATED.xml"

# ===============================
# LOAD XML TEMPLATE
# ===============================

parser = etree.XMLParser(remove_blank_text=False)
tree = etree.parse(xml_file, parser)
root = tree.getroot()

ns = {
    "d": "http://diggsml.org/schemas/3",
    "gml": "http://www.opengis.net/gml/3.2"
}

# ===============================
# LOAD EXCEL SHEETS
# ===============================

df_summary = pd.read_excel(excel_file, sheet_name="1_Project_Summary")
df_grid = pd.read_excel(excel_file, sheet_name="2_Grid_Map_Data")
df_ts = pd.read_excel(excel_file, sheet_name="3_Rig_Sensor_Data")

# =====================================================
# 1 UPDATE PROJECT SUMMARY (Remark content)
# =====================================================

remark_node = root.xpath(
    ".//d:Project//d:Remark//d:content",
    namespaces=ns
)

if remark_node:

    lines = []

    for _, row in df_summary.iterrows():
        key = str(row["Property"])
        val = str(row["Value"])
        lines.append(f"{key}: {val}")

    remark_node[0].text = " |\n                        ".join(lines)

# =====================================================
# 2 UPDATE GRID MAP DATA (Depth + Volume)
# =====================================================

grid_node = root.xpath(
    ".//d:measurement//d:dataValues",
    namespaces=ns
)

if grid_node:

    values = []

    for _, row in df_grid.iterrows():

        depth = row["Achieved Depth (m)"]
        volume = row["Grout Volume (m3)"]

        values.extend([depth, volume])

    grid_text = ", ".join(str(v) for v in values)

    grid_node[0].text = grid_text

# =====================================================
# 3 UPDATE RIG SENSOR DATA (TimeSeries)
# =====================================================

ts_node = root.xpath(
    ".//d:GroutingTimeSeries//d:dataValues",
    namespaces=ns
)

if ts_node:

    values = []

    for _, row in df_ts.iterrows():

        values.extend([
            row["Depth (m)"],
            row["Rotation (rpm)"],
            row["Torque (kN.m)"],
            row["Thrust (kN)"],
            row["Grout Pressure (bar)"],
            row["Grout Flow (L/min)"]
        ])

    ts_text = ", ".join(str(v) for v in values)

    ts_node[0].text = ts_text

# ===============================
# SAVE XML
# ===============================

tree.write(
    output_xml,
    encoding="utf-8",
    xml_declaration=True,
    pretty_print=True
)

print("✅ XML updated from all Excel sheets")

# ===============================
# DOWNLOAD (COLAB)
# ===============================

try:
    from google.colab import files
    files.download(output_xml)
except:
    pass