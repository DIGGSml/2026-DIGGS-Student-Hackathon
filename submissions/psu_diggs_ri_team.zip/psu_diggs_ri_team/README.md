# Standardizing Rigid Inclusion Data Using DIGGS

This project investigates how rigid inclusion (CMC) construction data can be systematically represented within the DIGGS framework by extracting parameters from international standards, organizing them across the RI project lifecycle, and validating the structure through a real case study and supporting data tools.

## Team

PSU Team

* Mohammed AlReshidi
* Abdulrahman Mohammed
* Eng. Nooran Edries
* Supervisor: Dr. Mohamed Ezzat

## Challenge Themes

* Data In / Data Out
* Data Transformation
* Visualization

## Project Description

Rigid Inclusion (RI) systems are widely used in ground improvement projects and generate significant amounts of construction and monitoring data. However, the current DIGGS schema does not include dedicated elements specifically designed to represent RI construction activities.

This project explores how RI data can be structured within the DIGGS framework by analyzing and standardizing key parameters extracted from multiple international standards and references, including ASIRI, FHWA, BS8006, and DGGT.

The extracted parameters were organized according to the RI project lifecycle phases (pre-installation, installation, and post-installation) and then mapped to existing DIGGS schema elements to evaluate the capability of DIGGS in representing RI systems.

## Case Study

A real CMC ground improvement project was used to validate the approach.

Project characteristics:

* 1050 columns installed
* 2 m grid spacing
* Installation using displacement augers

Available data included:

* Column coordinates
* Installation depth
* Grout volume
* Installation monitoring parameters

The project dataset was implemented using DIGGS XML to assess how RI construction data can be represented within the existing schema.

## Tools Developed

DIGGS XML → Excel Converter  
Extracts structured project data from DIGGS XML into a spreadsheet format.

Excel → DIGGS XML Converter  
Allows engineers to modify project data and regenerate a validated DIGGS XML dataset.

Engineering Visualization  
Generated a layout visualization of the CMC column grid using the structured DIGGS dataset.

## Technologies Used

* Python
* XML (DIGGS)
* Pandas
* Matplotlib
* XlsxWriter

## Repository Structure

src/ – Python scripts for converters and data processing  
docs/ – project documentation  
demo/ – presentation and demonstration materials  


